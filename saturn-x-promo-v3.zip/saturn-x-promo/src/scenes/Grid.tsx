import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {C, FONT_DISPLAY, ease, prog} from "../theme";
import {Eyebrow, Line, Scene} from "../ui";

const CMDS = [
  "/play", "/lirik", "/shazam", "/tts", "/quran", "/cariayat",
  "/ytmp3", "/ytmp4", "/ocr", "/removebg", "/edit", "/text2img",
  "/cekip", "/dns", "/ssweb", "/scanvirus", "/shorturl", "/cuaca",
  "/gempa", "/kurs", "/kbbi", "/tosticker", "/brat", "/tempmail",
];

export const Grid: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Scene>
      <AbsoluteFill style={{background: "rgba(6,3,13,0.45)"}} />
      <div style={{position: "absolute", left: 140, top: 96}}>
        <Eyebrow delay={2}>Command</Eyebrow>
        <div style={{height: 26}} />
        <Line size={92} delay={6} gradient>Masih ada 80+ lainnya.</Line>
      </div>
      <div style={{position: "absolute", left: 140, right: 140, top: 330, display: "grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 14}}>
        {CMDS.map((c, i) => {
          const col = i % 6, row = Math.floor(i / 6);
          const d = 12 + (col + row) * 3;
          const enter = prog(f, d, 18, ease.out);
          const hit = prog(f, d + 18, 12, ease.out) * (1 - prog(f, d + 40, 16, ease.inOut));
          return (
            <div key={c} style={{
              height: 112, borderRadius: 18, display: "flex", alignItems: "center", padding: "0 24px",
              fontFamily: FONT_DISPLAY, fontWeight: 500, fontSize: 34, letterSpacing: -0.8, color: C.paper,
              opacity: enter, transform: `translateY(${(1 - enter) * 16}px)`,
              background: `linear-gradient(135deg, rgba(139,108,255,${0.10 + hit * 0.32}), rgba(18,10,40,0.5))`,
              border: `1px solid rgba(205,187,255,${0.16 + hit * 0.5})`,
              boxShadow: `inset 0 1px 0 rgba(255,255,255,0.08), 0 0 ${hit * 40}px rgba(139,108,255,${hit * 0.5})`,
              backdropFilter: "blur(10px)",
            }}>
              {c}
            </div>
          );
        })}
      </div>
    </Scene>
  );
};
