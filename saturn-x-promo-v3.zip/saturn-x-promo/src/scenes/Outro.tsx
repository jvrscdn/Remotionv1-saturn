import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {C, FONT_BODY, FONT_DISPLAY, prog} from "../theme";
import {Eyebrow, Line, Scene} from "../ui";
import {GlowTitle, Hero} from "../hero";

export const Outro: React.FC = () => {
  const f = useCurrentFrame();
  const pill = prog(f, 30, 20);
  return (
    <Scene outF={34}>
      <AbsoluteFill>
        <Hero size={1120} delay={0} style={{position: "absolute", right: -60, top: -40}} />
        <GlowTitle width={920} delay={26} style={{position: "absolute", left: 960, top: 790}} />
        <div style={{position: "absolute", left: 140, top: 270}}>
          <Eyebrow delay={4}>Mulai sekarang</Eyebrow>
          <div style={{height: 34}} />
          <Line size={150} delay={8} gradient>Ketik /start</Line>
          <div style={{height: 40}} />
          <div style={{display: "inline-flex", alignItems: "center", gap: 16, padding: "18px 34px", borderRadius: 100, opacity: pill, transform: `translateY(${(1 - pill) * 12}px)`,
            background: "linear-gradient(135deg, rgba(139,108,255,0.3), rgba(75,43,214,0.22))", border: "1px solid rgba(205,187,255,0.45)",
            boxShadow: "0 0 60px rgba(139,108,255,0.35), inset 0 1px 0 rgba(255,255,255,0.18)", backdropFilter: "blur(14px)"}}>
            <span style={{fontFamily: FONT_DISPLAY, fontWeight: 600, fontSize: 54, color: "#fff", letterSpacing: -1}}>@Saturn3Xbot</span>
          </div>
          <div style={{fontFamily: FONT_BODY, fontSize: 34, color: C.muted, opacity: prog(f, 46, 16), marginTop: 36, lineHeight: 1.5}}>
            Lalu buka <b style={{color: C.paper, fontFamily: FONT_DISPLAY}}>/app</b> dan coba <b style={{color: C.paper, fontFamily: FONT_DISPLAY}}>/spotify</b>.
          </div>
        </div>
      </AbsoluteFill>
    </Scene>
  );
};
