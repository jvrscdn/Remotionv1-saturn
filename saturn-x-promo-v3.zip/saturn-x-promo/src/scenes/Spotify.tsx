import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {C, FONT_BODY, ease, prog} from "../theme";
import {Eyebrow, Line, Phone, Scene} from "../ui";
import {HomeScreen, SearchScreen, PlayerScreen, LibraryScreen, TogetherScreen, G} from "./SpotifyScreens";

const SEG = 132;
const SCREENS = [HomeScreen, SearchScreen, PlayerScreen, LibraryScreen, TogetherScreen];
const NAMES = ["Beranda dan rekomendasi", "Cari dan jelajah kategori", "Pemutar dengan lirik berwaktu", "Koleksi dan bagikan playlist", "Dengerin Bareng"];

export const Spotify: React.FC = () => {
  const f = useCurrentFrame();
  const idx = Math.min(SCREENS.length - 1, Math.floor(f / SEG));
  const local = f - idx * SEG;
  const t = idx > 0 ? prog(local, 0, 16, ease.inOut) : 1;
  const Cur = SCREENS[idx];
  const Prev = idx > 0 ? SCREENS[idx - 1] : null;
  return (
    <Scene>
      <AbsoluteFill style={{background: "linear-gradient(90deg, rgba(6,3,13,0.66) 0%, rgba(6,3,13,0.22) 70%)"}} />
      <div style={{position: "absolute", left: 140, top: 112}}>
        <Eyebrow delay={2}>Mini App</Eyebrow>
        <div style={{height: 30}} />
        <Line size={82} delay={4} gradient>Pemutar musik lengkap,</Line>
        <Line size={82} delay={10} gradient>di dalam Telegram.</Line>
        <div style={{height: 30}} />
        <div style={{fontFamily: FONT_BODY, fontSize: 30, color: C.muted, opacity: prog(f, 20, 16)}}>
          Tampilan ala Spotify, berjalan sebagai Mini App.
        </div>
        <div style={{marginTop: 48, width: 760}}>
          {NAMES.map((n, i) => {
            const on = i === idx;
            const fill = on ? prog(local, 0, SEG - 6, (x) => x) : i < idx ? 1 : 0;
            return (
              <div key={n} style={{display: "flex", alignItems: "center", gap: 24, height: 64, opacity: prog(f, 24 + i * 4, 14)}}>
                <div style={{width: 4, height: 38, borderRadius: 4, background: "rgba(205,187,255,0.18)", position: "relative", overflow: "hidden"}}>
                  <div style={{position: "absolute", left: 0, top: 0, width: 4, height: `${fill * 100}%`, background: G, boxShadow: `0 0 12px ${G}`}} />
                </div>
                <div style={{fontFamily: FONT_BODY, fontSize: 34, fontWeight: on ? 600 : 400, letterSpacing: -0.4, color: on ? "#fff" : "rgba(205,187,255,0.42)"}}>{n}</div>
              </div>
            );
          })}
        </div>
      </div>
      <div style={{position: "absolute", right: 170, top: 36}}>
        <Phone width={496} delay={4}>
          <div style={{position: "absolute", inset: 0, overflow: "hidden"}}>
            {Prev && t < 1 && (
              <div style={{position: "absolute", inset: 0, transform: `translateX(${-t * 28}%)`, filter: `brightness(${1 - t * 0.55})`}}>
                <Prev f={SEG + local} />
              </div>
            )}
            <div style={{position: "absolute", inset: 0, transform: `translateX(${(1 - t) * 100}%)`}}>
              <Cur f={local} />
            </div>
          </div>
        </Phone>
      </div>
    </Scene>
  );
};
