import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {C, FONT_BODY, FONT_DISPLAY, prog, ease} from "../theme";
import {Eyebrow, Line, Phone, Pill, Scene} from "../ui";
import {ChatScreen, Msg} from "./Chat";

const SLIDE = 120;

type Slide = {l1: string; l2: string; body: string; cmds: string[]; msgs: Msg[]};

const SLIDES: Slide[] = [
  {
    l1: "Tempel link,", l2: "video langsung jadi.",
    body: "TikTok, Instagram, Facebook, X, Pinterest, SoundCloud, dan 20+ platform lain.",
    cmds: ["/downloader", "/ytmp3", "/ytmp4"],
    msgs: [
      {who: "me", at: 10, kind: "text", text: "https://vt.tiktok.com/ZSa9k2xQ/"},
      {who: "bot", at: 44, kind: "text", text: "Mengunduh video...", typing: 20},
      {who: "bot", at: 78, kind: "file", name: "tiktok_video.mp4", size: "18,4 MB", typing: 22},
    ],
  },
  {
    l1: "Bikin dan edit gambar", l2: "tanpa pindah aplikasi.",
    body: "Dari teks jadi gambar, hapus latar, ubah jadi anime, tukar wajah.",
    cmds: ["/text2img", "/removebg", "/jadianime"],
    msgs: [
      {who: "me", at: 10, kind: "text", text: "/text2img manusia galaksi, gaya anime"},
      {who: "bot", at: 56, kind: "image", caption: "Selesai. Mau ubah gaya? Coba /jadianime", typing: 30},
      {who: "me", at: 96, kind: "text", text: "/removebg"},
    ],
  },
  {
    l1: "Murottal per ayat,", l2: "tinggal ketik.",
    body: "Sebut surah, nomor ayat, dan nama qari. Bot memotong audionya untukmu.",
    cmds: ["/murottal", "/quran", "/cariayat"],
    msgs: [
      {who: "me", at: 10, kind: "text", text: "/murottal Al-Mulk ayat 1-5 Alafasy"},
      {who: "bot", at: 52, kind: "audio", title: "Al-Mulk · ayat 1-5", sub: "Mishary Alafasy", dur: "0:42", typing: 26},
    ],
  },
  {
    l1: "Cek web dan jaringan", l2: "sekali ketik.",
    body: "IP, DNS, domain, status situs, sampai tangkapan layar halaman.",
    cmds: ["/cekweb", "/dns", "/ssweb"],
    msgs: [
      {who: "me", at: 10, kind: "text", text: "/cekweb example.com"},
      {who: "bot", at: 50, kind: "text", text: "example.com\nStatus: 200 OK\nRespons: 84 ms\nSSL: aktif", typing: 24},
      {who: "me", at: 92, kind: "text", text: "/ssweb example.com"},
    ],
  },
];

export const Features: React.FC = () => {
  const f = useCurrentFrame();
  const idx = Math.min(SLIDES.length - 1, Math.floor(f / SLIDE));
  const local = f - idx * SLIDE;
  const s = SLIDES[idx];
  return (
    <Scene>
      <AbsoluteFill style={{background: "linear-gradient(90deg, rgba(6,3,13,0.62) 0%, rgba(6,3,13,0.2) 70%)"}} />
      <div style={{position: "absolute", left: 140, top: 112, display: "flex", alignItems: "center", gap: 22}}>
        <Eyebrow delay={2}>Fitur</Eyebrow>
        <div style={{display: "flex", gap: 8, marginLeft: 10}}>
          {SLIDES.map((_, i) => (
            <div key={i} style={{width: 56, height: 3, borderRadius: 3, background: "rgba(205,187,255,0.22)", overflow: "hidden"}}>
              <div style={{width: i < idx ? "100%" : i === idx ? `${prog(local, 0, SLIDE, (x) => x) * 100}%` : "0%", height: "100%", background: C.lilac}} />
            </div>
          ))}
        </div>
      </div>
      <div key={idx} style={{position: "absolute", left: 140, top: 250, width: 1000}}>
        <Line size={84} delay={2} gradient>{s.l1}</Line>
        <Line size={84} delay={8} gradient>{s.l2}</Line>
        <div style={{height: 40}} />
        <div style={{fontFamily: FONT_BODY, fontSize: 31, lineHeight: 1.5, color: C.muted, maxWidth: 700, opacity: prog(local, 16, 16)}}>
          {s.body}
        </div>
        <div style={{display: "flex", gap: 14, marginTop: 40}}>
          {s.cmds.map((c, i) => <Pill key={c} delay={24 + i * 5}>{c}</Pill>)}
        </div>
      </div>
      <div style={{position: "absolute", right: 170, top: 36}}>
        <Phone width={480} delay={6}>
          <ChatScreen f={local} msgs={s.msgs} />
        </Phone>
      </div>
    </Scene>
  );
};
