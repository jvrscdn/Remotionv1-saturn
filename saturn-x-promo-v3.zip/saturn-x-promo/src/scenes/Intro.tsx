import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {C, FONT_BODY, prog} from "../theme";
import {Eyebrow, Line, Scene} from "../ui";
import {GlowTitle, Hero} from "../hero";

export const Intro: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Scene first>
      <AbsoluteFill>
        <Hero size={1120} delay={0} style={{position: "absolute", right: -60, top: -40}} />
        <GlowTitle width={920} delay={26} style={{position: "absolute", left: 960, top: 790}} />
        <div style={{position: "absolute", left: 140, top: 300}}>
          <Eyebrow delay={22}>Bot Telegram</Eyebrow>
          <div style={{height: 34}} />
          <Line size={90} delay={30} gradient>Satu bot untuk</Line>
          <Line size={90} delay={38} gradient>semua perangkatmu.</Line>
          <div style={{height: 38}} />
          <div style={{fontFamily: FONT_BODY, fontSize: 32, color: C.muted, opacity: prog(f, 58, 20), lineHeight: 1.5, maxWidth: 640}}>
            Musik, unduhan, AI, dan alat jaringan.<br />Semuanya di dalam satu chat.
          </div>
        </div>
      </AbsoluteFill>
    </Scene>
  );
};
