import React from "react";
import {C, FONT_BODY, FONT_DISPLAY, prog, ease} from "../theme";
import {Icon, StatusBar} from "../ui";
import {Img, staticFile} from "remotion";

export type Msg =
  | {who: "me" | "bot"; at: number; kind: "text"; text: string; typing?: number}
  | {who: "bot"; at: number; kind: "file"; name: string; size: string; typing?: number}
  | {who: "bot"; at: number; kind: "image"; caption: string; typing?: number}
  | {who: "bot"; at: number; kind: "audio"; title: string; sub: string; dur: string; typing?: number};

const BG = "#0E1621";
const IN = "#182533";
const OUT = "#2B5278";
const BLUE = "#6AB3F3";

const Rich: React.FC<{text: string}> = ({text}) => {
  const parts = text.split(/(\/[a-z0-9]+|https?:\/\/\S+)/g);
  return (
    <>
      {parts.map((p, i) =>
        /^(\/[a-z0-9]+|https?:\/\/\S+)$/.test(p) ? <span key={i} style={{color: BLUE}}>{p}</span> : <span key={i}>{p}</span>
      )}
    </>
  );
};

const Dots: React.FC<{f: number}> = ({f}) => (
  <div style={{alignSelf: "flex-start", background: IN, borderRadius: "16px 16px 16px 4px", padding: "14px 16px", display: "flex", gap: 5}}>
    {[0, 1, 2].map((i) => (
      <span key={i} style={{width: 7, height: 7, borderRadius: 7, background: "#7C8B99", opacity: 0.45 + 0.55 * Math.max(0, Math.sin((f - i * 4) / 3.2))}} />
    ))}
  </div>
);

const Body: React.FC<{m: Msg; f: number}> = ({m, f}) => {
  if (m.kind === "text") {
    return <div style={{whiteSpace: "pre-line"}}><Rich text={m.text} /></div>;
  }
  if (m.kind === "file") {
    const pr = prog(f, m.at, 18, ease.inOut);
    return (
      <div style={{display: "flex", gap: 12, alignItems: "center", width: 250}}>
        <div style={{width: 48, height: 48, borderRadius: 48, background: "#3F8FD2", display: "flex", alignItems: "center", justifyContent: "center", position: "relative"}}>
          <Icon name={pr >= 1 ? "play" : "download"} size={22} color="#fff" />
        </div>
        <div>
          <div style={{fontWeight: 700, fontSize: 16}}>{m.name}</div>
          <div style={{fontSize: 14, color: "#8FA2B3", marginTop: 2}}>{m.size}</div>
        </div>
      </div>
    );
  }
  if (m.kind === "image") {
    return (
      <div style={{width: 260}}>
        <Img src={staticFile("hero-half.jpg")} style={{width: 260, height: 190, objectFit: "cover", objectPosition: "50% 22%", borderRadius: 10, display: "block"}} />
        <div style={{marginTop: 8, fontSize: 15}}><Rich text={m.caption} /></div>
      </div>
    );
  }
  const bars = Array.from({length: 30}, (_, i) => 6 + Math.abs(Math.sin(i * 1.7) * 14) + (i % 4) * 2);
  const play = prog(f, m.at + 8, 80, ease.inOut);
  return (
    <div style={{width: 270}}>
      <div style={{display: "flex", alignItems: "center", gap: 12}}>
        <div style={{width: 46, height: 46, borderRadius: 46, background: "#3F8FD2", display: "flex", alignItems: "center", justifyContent: "center"}}>
          <Icon name="pause" size={20} color="#fff" />
        </div>
        <div style={{display: "flex", alignItems: "center", gap: 2.5, height: 30}}>
          {bars.map((h, i) => (
            <span key={i} style={{width: 3, height: h, borderRadius: 2, background: i / bars.length < play ? "#9CD0FF" : "#4D6A86"}} />
          ))}
        </div>
      </div>
      <div style={{marginTop: 8, fontWeight: 700, fontSize: 16}}>{m.title}</div>
      <div style={{fontSize: 14, color: "#8FA2B3"}}>{m.sub} · {m.dur}</div>
    </div>
  );
};

export const ChatScreen: React.FC<{f: number; msgs: Msg[]}> = ({f, msgs}) => {
  return (
    <div style={{position: "absolute", inset: 0, background: BG, fontFamily: FONT_BODY, color: "#fff"}}>
      <div style={{background: "#17212B", height: 100}}>
        <StatusBar />
        <div style={{display: "flex", alignItems: "center", gap: 12, padding: "2px 16px"}}>
          <Icon name="back" size={24} color="#6AB3F3" />
          <div style={{width: 40, height: 40, borderRadius: 40, overflow: "hidden", boxShadow: "0 0 0 1.5px rgba(139,108,255,0.7)"}}>
            <Img src={staticFile("planet.jpg")} style={{width: "100%", height: "100%", objectFit: "cover"}} />
          </div>
          <div>
            <div style={{fontFamily: FONT_DISPLAY, fontWeight: 700, fontSize: 18}}>Saturn X</div>
            <div style={{fontSize: 13, color: "#6D7F8F"}}>bot</div>
          </div>
        </div>
      </div>
      <div style={{display: "flex", flexDirection: "column", gap: 10, padding: "18px 14px"}}>
        {msgs.map((m, i) => {
          const typing = m.who === "bot" && m.typing && f >= m.at - m.typing && f < m.at;
          if (typing) return <Dots key={i} f={f} />;
          if (f < m.at) return null;
          const p = prog(f, m.at, 8);
          const me = m.who === "me";
          return (
            <div
              key={i}
              style={{
                alignSelf: me ? "flex-end" : "flex-start",
                maxWidth: 300,
                background: me ? OUT : IN,
                borderRadius: me ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
                padding: "9px 13px 10px",
                fontSize: 17,
                lineHeight: 1.32,
                opacity: p,
                transform: `translateY(${(1 - p) * 10}px)`,
              }}
            >
              <Body m={m} f={f} />
            </div>
          );
        })}
      </div>
      <div style={{position: "absolute", left: 0, right: 0, bottom: 0, height: 66, background: "#17212B", display: "flex", alignItems: "center", padding: "0 18px 10px", color: "#6D7F8F", fontSize: 17}}>
        Pesan
      </div>
    </div>
  );
};
