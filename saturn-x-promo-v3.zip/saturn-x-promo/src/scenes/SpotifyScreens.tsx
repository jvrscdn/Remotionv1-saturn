import React from "react";
import {C, FONT_SPOT, ease, prog} from "../theme";
import {Cover, Icon, StatusBar, coverTone} from "../ui";

export const G = "#1ED760";
const BG = "#121212";
const CARD = "#2A2A2A";
const SUB = "#B3B3B3";

const Fade: React.FC<{f: number; d: number; children: React.ReactNode; style?: React.CSSProperties}> = ({f, d, children, style}) => {
  const p = prog(f, d, 14);
  return <div style={{opacity: p, transform: `translateY(${(1 - p) * 10}px)`, ...style}}>{children}</div>;
};

const Shell: React.FC<{children: React.ReactNode; bg?: string}> = ({children, bg = BG}) => (
  <div style={{position: "absolute", inset: 0, background: bg, fontFamily: FONT_SPOT, color: "#fff", overflow: "hidden"}}>{children}</div>
);

const Nav: React.FC<{active: 0 | 1 | 2}> = ({active}) => {
  const items: {n: "home" | "search" | "library" | "plus"; t: string}[] = [
    {n: "home", t: "Beranda"}, {n: "search", t: "Cari"}, {n: "library", t: "Koleksi Kamu"}, {n: "plus", t: "Buat"},
  ];
  return (
    <div style={{position: "absolute", left: 0, right: 0, bottom: 0, height: 80, background: "linear-gradient(180deg, rgba(0,0,0,0.0) 0%, rgba(0,0,0,0.9) 30%, #000 100%)", display: "flex", justifyContent: "space-around", alignItems: "flex-start", paddingTop: 16, zIndex: 20}}>
      {items.map((it, i) => (
        <div key={it.t} style={{display: "flex", flexDirection: "column", alignItems: "center", gap: 5, color: i === active ? "#fff" : SUB, fontSize: 10.5, fontWeight: 600, width: 80}}>
          {it.n === "plus" ? (
            <div style={{width: 24, height: 24, borderRadius: 24, border: `2px solid ${SUB}`, display: "flex", alignItems: "center", justifyContent: "center"}}><Icon name="plus" size={16} color={SUB} /></div>
          ) : (
            <Icon name={it.n} size={24} color={i === active ? "#fff" : SUB} outline={it.n === "home" && i !== active} />
          )}
          {it.t}
        </div>
      ))}
    </div>
  );
};

const MiniPlayer: React.FC<{f: number}> = ({f}) => (
  <div style={{position: "absolute", left: 8, right: 8, bottom: 86, height: 56, borderRadius: 8, background: coverTone(0), zIndex: 21, boxShadow: "0 6px 20px rgba(0,0,0,0.35)", display: "flex", alignItems: "center", padding: "0 12px 0 8px", gap: 10}}>
    <Cover seed={0} size={40} />
    <div style={{flex: 1}}>
      <div style={{fontSize: 14, fontWeight: 700}}>Lampu Kota</div>
      <div style={{fontSize: 12, color: "rgba(255,255,255,0.72)"}}>Rinai Malam</div>
    </div>
    <Icon name="heart" size={22} color={G} />
    <Icon name="play" size={24} />
    <div style={{position: "absolute", left: 10, right: 10, bottom: 2, height: 2, background: "rgba(255,255,255,0.25)"}}>
      <div style={{width: `${20 + f / 4}%`, height: "100%", background: "#fff"}} />
    </div>
  </div>
);

/* ---------- 1. Beranda ---------- */
export const HomeScreen: React.FC<{f: number}> = ({f}) => {
  const scroll = prog(f, 40, 80, ease.inOut) * 70;
  const tiles = ["Lagu Disukai", "Malam Tenang", "Fokus Kerja", "Jalan Pagi", "Hits Hari Ini", "Throwback"];
  return (
    <Shell>
      <div style={{position: "absolute", top: 0, left: 0, right: 0, height: 330, background: `linear-gradient(180deg, ${coverTone(4)}CC 0%, ${BG} 100%)`}} />
      <div style={{position: "absolute", top: 0, left: 0, right: 0, zIndex: 5}}><StatusBar /></div>
      <div style={{transform: `translateY(${-scroll}px)`, paddingTop: 46}}>
        <div style={{padding: "10px 16px 0"}}>
          <Fade f={f} d={0}>
            <div style={{display: "flex", gap: 8, alignItems: "center"}}>
              <div style={{width: 34, height: 34, borderRadius: 34, background: C.gold, color: C.ink, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15}}>J</div>
              {["Semua", "Musik", "Terbaru"].map((c, i) => (
                <div key={c} style={{padding: "7px 14px", borderRadius: 20, fontSize: 13, fontWeight: 700, background: i === 0 ? G : "rgba(255,255,255,0.12)", color: i === 0 ? "#000" : "#fff"}}>{c}</div>
              ))}
            </div>
          </Fade>
          <div style={{display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginTop: 18}}>
            {tiles.map((t, i) => (
              <Fade key={t} f={f} d={6 + i * 3}>
                <div style={{height: 52, background: CARD, borderRadius: 5, display: "flex", alignItems: "center", gap: 10, overflow: "hidden", paddingRight: 8}}>
                  <Cover seed={i + 1} size={52} radius={0} />
                  <span style={{fontSize: 13, fontWeight: 700, lineHeight: 1.15}}>{t}</span>
                </div>
              </Fade>
            ))}
          </div>
          <Fade f={f} d={28}>
            <div style={{fontFamily: FONT_SPOT, fontWeight: 800, fontSize: 22, marginTop: 26, letterSpacing: -0.5}}>Dibuat untuk kamu</div>
            <div style={{display: "flex", gap: 12, marginTop: 12}}>
              {[["Campuran Harian 1", "Rinai Malam, Kala, Sunyi"], ["Campuran Harian 2", "Laut Biru, Dara, Anta"], ["Rilisan Radar", "Lagu baru untukmu"]].map(([t, s], i) => (
                <div key={t} style={{width: 112}}>
                  <Cover seed={i * 2 + 2} size={112} />
                  <div style={{fontSize: 12.5, fontWeight: 700, marginTop: 8}}>{t}</div>
                  <div style={{fontSize: 11.5, color: SUB, marginTop: 2, lineHeight: 1.25}}>{s}</div>
                </div>
              ))}
            </div>
          </Fade>
          <Fade f={f} d={40}>
            <div style={{fontFamily: FONT_SPOT, fontWeight: 800, fontSize: 22, marginTop: 26, letterSpacing: -0.5}}>Saran lagu</div>
            {["Jalan Pelan", "Hujan di Kota", "Pulang"].map((t, i) => (
              <div key={t} style={{display: "flex", alignItems: "center", gap: 12, marginTop: 12}}>
                <Cover seed={i + 5} size={48} />
                <div style={{flex: 1}}>
                  <div style={{fontSize: 14, fontWeight: 700}}>{t}</div>
                  <div style={{fontSize: 12, color: SUB}}>{["Kala", "Dara", "Anta"][i]}</div>
                </div>
                <Icon name="more" size={22} color={SUB} />
              </div>
            ))}
          </Fade>
        </div>
      </div>
      <MiniPlayer f={f} />
      <Nav active={0} />
    </Shell>
  );
};

/* ---------- 2. Cari ---------- */
export const SearchScreen: React.FC<{f: number}> = ({f}) => {
  const q = "lofi santai";
  const n = Math.floor(prog(f, 34, 38, ease.inOut) * q.length);
  const cats = [
    ["Pop", "#E8505B"], ["Hip-Hop", "#BA5D07"], ["Indie", "#1E8F6E"], ["Dangdut", "#8D67AB"],
    ["Santai", "#477D95"], ["Olahraga", "#E13300"], ["Rock", "#7358FF"], ["Akustik", "#B49BC8"],
  ];
  const scroll = prog(f, 80, 44, ease.inOut) * 60;
  return (
    <Shell>
      <div style={{position: "absolute", top: 0, left: 0, right: 0, height: 150, zIndex: 5, background: BG}}>
        <StatusBar />
        <div style={{padding: "8px 16px 0"}}>
          <div style={{fontFamily: FONT_SPOT, fontWeight: 800, fontSize: 28, letterSpacing: -0.6}}>Cari</div>
          <div style={{height: 46, borderRadius: 6, background: "#fff", marginTop: 14, display: "flex", alignItems: "center", gap: 10, padding: "0 12px", color: "#000", fontSize: 16, fontWeight: 500}}>
            <Icon name="search" size={22} color="#000" />
            {n === 0 ? <span style={{color: "#6A6A6A"}}>Mau dengerin apa?</span> : <span>{q.slice(0, n)}<span style={{opacity: f % 16 < 8 ? 1 : 0}}>|</span></span>}
          </div>
        </div>
      </div>
      <div style={{position: "absolute", top: 150, left: 0, right: 0, bottom: 0, padding: "0 16px", transform: `translateY(${-scroll}px)`}}>
        <Fade f={f} d={4}>
          <div style={{fontSize: 17, fontWeight: 800, marginTop: 22}}>Jelajahi semua</div>
        </Fade>
        <div style={{display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginTop: 12}}>
          {cats.map(([t, col], i) => (
            <Fade key={t} f={f} d={8 + i * 3}>
              <div style={{height: 96, borderRadius: 8, background: col, position: "relative", overflow: "hidden", padding: 12, fontWeight: 800, fontSize: 17}}>
                {t}
                <div style={{position: "absolute", right: -12, bottom: -4, transform: "rotate(25deg)"}}>
                  <Cover seed={i + 1} size={62} radius={3} />
                </div>
              </div>
            </Fade>
          ))}
        </div>
      </div>
      <MiniPlayer f={f} />
      <Nav active={1} />
    </Shell>
  );
};

/* ---------- 3. Pemutar + lirik ---------- */
const LYRICS = [
  "Lampu kota menyala pelan",
  "Kita jalan tanpa tujuan",
  "Malam ini terasa panjang",
  "Tapi kamu di sebelahku",
];
const LYRIC_AT = [0, 34, 68, 102];

export const PlayerScreen: React.FC<{f: number}> = ({f}) => {
  const cur = LYRIC_AT.filter((t) => f >= t).length - 1;
  const total = 204;
  const sec = 36 + f / 30;
  const mm = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
  const pct = (sec / total) * 100;
  const pulse = 1 + 0.012 * Math.sin(f / 6);
  return (
    <Shell bg={`linear-gradient(180deg, ${coverTone(0)} 0%, #1A1A1A 62%, #121212 100%)`}>
      <StatusBar />
      <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", padding: "6px 18px 0"}}>
        <Icon name="down" size={26} />
        <div style={{fontSize: 12, fontWeight: 700, textAlign: "center", lineHeight: 1.3}}>
          <div style={{color: "rgba(255,255,255,0.7)", fontWeight: 500}}>Diputar dari playlist</div>
          Malam Tenang
        </div>
        <Icon name="more" size={26} />
      </div>
      <div style={{display: "flex", justifyContent: "center", marginTop: 20, transform: `scale(${pulse})`}}>
        <div style={{boxShadow: "0 24px 50px rgba(0,0,0,0.5)", borderRadius: 6}}><Cover seed={0} size={292} radius={6} /></div>
      </div>
      <div style={{padding: "20px 24px 0", display: "flex", alignItems: "center"}}>
        <div style={{flex: 1}}>
          <div style={{fontFamily: FONT_SPOT, fontWeight: 800, fontSize: 24, letterSpacing: -0.5}}>Lampu Kota</div>
          <div style={{fontSize: 15, color: "rgba(255,255,255,0.7)", marginTop: 2}}>Rinai Malam</div>
        </div>
        <Icon name="heart" size={26} color={G} />
      </div>
      <div style={{padding: "14px 24px 0"}}>
        <div style={{height: 4, borderRadius: 4, background: "rgba(255,255,255,0.28)", position: "relative"}}>
          <div style={{width: `${pct}%`, height: "100%", background: "#fff", borderRadius: 4}} />
          <div style={{position: "absolute", left: `${pct}%`, top: -4, width: 12, height: 12, borderRadius: 12, background: "#fff", marginLeft: -6}} />
        </div>
        <div style={{display: "flex", justifyContent: "space-between", fontSize: 11.5, color: "rgba(255,255,255,0.7)", marginTop: 6}}>
          <span>{mm(sec)}</span><span>{mm(total)}</span>
        </div>
      </div>
      <div style={{display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 30px 0"}}>
        <Icon name="shuffle" size={24} color={G} />
        <Icon name="prev" size={30} />
        <div style={{width: 62, height: 62, borderRadius: 62, background: "#fff", display: "flex", alignItems: "center", justifyContent: "center"}}>
          <Icon name="pause" size={28} color="#000" />
        </div>
        <Icon name="next" size={30} />
        <Icon name="repeat" size={24} color="#fff" />
      </div>
      <div style={{position: "absolute", left: 14, right: 14, bottom: 18, borderRadius: 12, background: coverTone(0), padding: "16px 20px", boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.06)"}}>
        {LYRICS.map((l, i) => (
          <div key={l} style={{fontFamily: FONT_SPOT, fontSize: i === cur ? 19 : 17, fontWeight: 800, lineHeight: 1.45, letterSpacing: -0.2, color: i === cur ? "#fff" : i < cur ? "rgba(255,255,255,0.55)" : "rgba(0,0,0,0.5)"}}>
            {l}
          </div>
        ))}
      </div>
    </Shell>
  );
};

/* ---------- 4. Koleksi + bagikan link ---------- */
export const LibraryScreen: React.FC<{f: number}> = ({f}) => {
  const rows = [
    {t: "Lagu Disukai", s: "Playlist · 128 lagu", seed: 4},
    {t: "Malam Tenang", s: "Playlist · 24 lagu", seed: 0},
    {t: "Fokus Kerja", s: "Playlist · 41 lagu", seed: 3},
    {t: "Jalan Pagi", s: "Playlist · 18 lagu", seed: 1},
    {t: "Rinai Malam", s: "Artis", seed: 2},
    {t: "Kala", s: "Artis", seed: 6},
  ];
  const sheet = prog(f, 46, 18, ease.out);
  const copied = f > 92;
  return (
    <Shell>
      <StatusBar />
      <div style={{padding: "8px 16px 0"}}>
        <div style={{display: "flex", alignItems: "center", gap: 10}}>
          <div style={{width: 34, height: 34, borderRadius: 34, background: C.gold, color: C.ink, fontWeight: 800, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15}}>J</div>
          <div style={{fontFamily: FONT_SPOT, fontWeight: 800, fontSize: 24, letterSpacing: -0.5, flex: 1}}>Koleksi Kamu</div>
          <Icon name="plus" size={26} />
        </div>
        <div style={{display: "flex", gap: 8, marginTop: 14}}>
          {["Playlist", "Artis"].map((c, i) => (
            <div key={c} style={{padding: "7px 14px", borderRadius: 20, fontSize: 13, fontWeight: 700, background: i === 0 ? G : "rgba(255,255,255,0.12)", color: i === 0 ? "#000" : "#fff"}}>{c}</div>
          ))}
        </div>
        {rows.map((r, i) => (
          <Fade key={r.t} f={f} d={4 + i * 4}>
            <div style={{display: "flex", alignItems: "center", gap: 12, marginTop: 16}}>
              {i < 4 ? <Cover seed={r.seed} size={58} radius={4} /> : (
                <div style={{borderRadius: 58, overflow: "hidden", width: 58, height: 58}}><Cover seed={r.seed} size={58} radius={0} /></div>
              )}
              <div>
                <div style={{fontSize: 15, fontWeight: 700}}>{r.t}</div>
                <div style={{fontSize: 13, color: SUB, marginTop: 2}}>{r.s}</div>
              </div>
            </div>
          </Fade>
        ))}
      </div>
      <Nav active={2} />
      <div style={{position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", opacity: sheet}} />
      <div style={{position: "absolute", left: 0, right: 0, bottom: 0, height: 330, background: "#282828", borderRadius: "18px 18px 0 0", transform: `translateY(${(1 - sheet) * 340}px)`, padding: "22px 20px"}}>
        <div style={{display: "flex", alignItems: "center", gap: 14}}>
          <Cover seed={0} size={56} radius={4} />
          <div>
            <div style={{fontSize: 17, fontWeight: 800}}>Malam Tenang</div>
            <div style={{fontSize: 13, color: SUB}}>Playlist · 24 lagu</div>
          </div>
        </div>
        <div style={{display: "flex", alignItems: "center", gap: 10, marginTop: 20, fontSize: 15, fontWeight: 700}}>
          <Icon name="share" size={22} /> Bagikan lewat link
        </div>
        <div style={{marginTop: 14, background: "#121212", borderRadius: 8, padding: "13px 14px", fontSize: 14, color: "#6AB3F3", letterSpacing: 0.2}}>
          t.me/Saturn3Xbot?start=pl_k7Q2x
        </div>
        <div style={{marginTop: 16, height: 48, borderRadius: 48, background: copied ? "#fff" : G, color: "#000", fontWeight: 800, fontSize: 15, display: "flex", alignItems: "center", justifyContent: "center"}}>
          {copied ? "Tautan disalin" : "Salin tautan"}
        </div>
        <div style={{marginTop: 12, textAlign: "center", fontSize: 12.5, color: SUB}}>Penerima bisa menyimpannya ke Koleksi mereka.</div>
      </div>
    </Shell>
  );
};

/* ---------- 5. Dengerin Bareng ---------- */
export const TogetherScreen: React.FC<{f: number}> = ({f}) => {
  const people = [["R", "#E8505B"], ["B", "#2E86C1"], ["S", "#3FA796"], ["D", "#E86F3A"], ["J", C.gold]];
  const chat = [
    {at: 34, who: "Bimo", t: "gas lagu ini"},
    {at: 66, who: "Salsa", t: "tambahin yang tadi dong"},
    {at: 98, who: "Rani", t: "oke, masuk antrean"},
  ];
  return (
    <Shell>
      <StatusBar />
      <div style={{padding: "8px 18px 0"}}>
        <div style={{fontFamily: FONT_SPOT, fontWeight: 800, fontSize: 26, letterSpacing: -0.5}}>Dengerin Bareng</div>
        <Fade f={f} d={2}>
          <div style={{display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 14, background: CARD, borderRadius: 10, padding: "12px 14px"}}>
            <div>
              <div style={{fontSize: 12, color: SUB}}>Kode ruang</div>
              <div style={{fontFamily: FONT_SPOT, fontWeight: 800, fontSize: 36, letterSpacing: 7, color: G, lineHeight: 1.1}}>K7Q2X</div>
            </div>
            <div style={{textAlign: "right"}}>
              <div style={{display: "flex", justifyContent: "flex-end"}}>
                {people.map(([n, col], i) => (
                  <div key={n} style={{width: 30, height: 30, borderRadius: 30, background: col, color: "#000", fontWeight: 800, fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center", marginLeft: i ? -8 : 0, border: `2px solid ${CARD}`}}>{n}</div>
                ))}
              </div>
              <div style={{fontSize: 12, color: SUB, marginTop: 6}}>5 dari 8 teman</div>
            </div>
          </div>
        </Fade>
        <Fade f={f} d={10}>
          <div style={{display: "flex", alignItems: "center", gap: 12, marginTop: 14}}>
            <Cover seed={0} size={60} radius={4} />
            <div style={{flex: 1}}>
              <div style={{fontSize: 16, fontWeight: 800}}>Lampu Kota</div>
              <div style={{fontSize: 13, color: SUB}}>Rinai Malam · host: Rani</div>
            </div>
            <div style={{display: "flex", gap: 3, alignItems: "flex-end", height: 22}}>
              {[0, 1, 2, 3].map((i) => (
                <span key={i} style={{width: 4, borderRadius: 2, background: G, height: 6 + Math.abs(Math.sin((f + i * 5) / 4)) * 16}} />
              ))}
            </div>
          </div>
          <div style={{height: 4, background: "rgba(255,255,255,0.2)", borderRadius: 4, marginTop: 12}}>
            <div style={{width: `${30 + f / 3}%`, height: "100%", background: "#fff", borderRadius: 4}} />
          </div>
        </Fade>
        <Fade f={f} d={18}>
          <div style={{fontSize: 16, fontWeight: 800, marginTop: 20}}>Antrean</div>
          {[["Jalan Pelan", "Bimo", 5], ["Pulang", "Salsa", 6]].map(([t, w, s]) => (
            <div key={t as string} style={{display: "flex", alignItems: "center", gap: 12, marginTop: 10}}>
              <Cover seed={s as number} size={42} />
              <div style={{flex: 1}}>
                <div style={{fontSize: 14, fontWeight: 700}}>{t}</div>
                <div style={{fontSize: 12, color: SUB}}>ditambahkan {w}</div>
              </div>
            </div>
          ))}
        </Fade>
        <div style={{marginTop: 18, display: "flex", flexDirection: "column", gap: 8}}>
          {chat.map((c, i) => f >= c.at && (
            <div key={i} style={{alignSelf: "flex-start", background: CARD, borderRadius: "14px 14px 14px 4px", padding: "8px 12px", fontSize: 14, opacity: prog(f, c.at, 8)}}>
              <span style={{color: G, fontWeight: 700}}>{c.who}</span> {c.t}
            </div>
          ))}
        </div>
      </div>
      <div style={{position: "absolute", left: 14, right: 14, bottom: 18, height: 44, borderRadius: 44, background: CARD, color: SUB, fontSize: 14, display: "flex", alignItems: "center", padding: "0 18px"}}>
        Tulis pesan ke ruang
      </div>
    </Shell>
  );
};
