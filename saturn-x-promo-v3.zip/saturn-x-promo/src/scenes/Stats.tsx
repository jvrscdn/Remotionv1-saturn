import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {C, FONT_BODY, FONT_DISPLAY, ease, prog} from "../theme";
import {Eyebrow, Scene} from "../ui";

const ROWS = [
  {n: 110, suf: "+", label: "Fitur siap pakai", note: "Musik, unduhan, AI, dan alat jaringan."},
  {n: 20, suf: "+", label: "Platform unduhan", note: "TikTok, Instagram, X, SoundCloud, dan lainnya."},
  {n: 8, suf: "", label: "Teman per ruang dengar", note: "Dengerin Bareng, langsung di Mini App."},
];

export const Stats: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <Scene>
      <AbsoluteFill style={{background: "rgba(6,3,13,0.38)"}} />
      <div style={{position: "absolute", left: 140, top: 112}}><Eyebrow delay={4}>Dalam angka</Eyebrow></div>
      <div style={{position: "absolute", left: 140, right: 140, top: 250, display: "grid", gridTemplateColumns: "1.05fr 1fr 1fr", gap: 56}}>
        {ROWS.map((r, i) => {
          const d = 10 + i * 14;
          const p = prog(f, d, 56, ease.out);
          const line = prog(f, d - 4, 40, ease.inOut);
          return (
            <div key={r.label} style={{position: "relative", padding: "34px 0 0 0", opacity: Math.min(1, p * 3)}}>
              <div style={{position: "absolute", top: 0, left: 0, height: 2, width: `${line * 92}%`, background: `linear-gradient(90deg, ${C.violet}, rgba(139,108,255,0))`}} />
              <div style={{
                fontFamily: FONT_DISPLAY, fontWeight: 500, fontSize: 232, lineHeight: 0.95, letterSpacing: -10,
                fontVariantNumeric: "tabular-nums", color: "transparent",
                backgroundImage: `linear-gradient(180deg, #fff 8%, ${C.lilac} 55%, ${C.violet} 100%)`,
                WebkitBackgroundClip: "text", backgroundClip: "text",
                transform: `translateY(${(1 - p) * 24}px)`,
              }}>
                {Math.round(r.n * p)}{r.suf}
              </div>
              <div style={{fontFamily: FONT_DISPLAY, fontWeight: 600, fontSize: 44, color: C.paper, letterSpacing: -1, marginTop: 18}}>{r.label}</div>
              <div style={{fontFamily: FONT_BODY, fontSize: 26, color: C.muted, marginTop: 10, lineHeight: 1.4, maxWidth: 440}}>{r.note}</div>
            </div>
          );
        })}
      </div>
    </Scene>
  );
};
